AJH STAFF SOLUTION WEBSITE FILES

Included:
- index.html: complete responsive website
- Royal light theme with navy and gold styling
- Mahender Singh — Manager — +91 93156 48764 (click-to-call)
- Jubesh Kumar — Zonal Manager — +91 98772 72930 (click-to-call)
- Company contact email, phone and WhatsApp links
- Open Graph title/description metadata (an og:image still needs a publicly hosted image URL for rich link previews)

To preview:
Open index.html in a browser.

To make it publicly accessible:
Upload this folder to a static hosting service that supports free hosting (for example, GitHub Pages or Cloudflare Pages). These files alone are not a public live URL, and publishing requires an account/service setup. No paid service is required by the HTML itself.
